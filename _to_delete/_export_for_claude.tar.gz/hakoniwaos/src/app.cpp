/* SPDX-License-Identifier: Apache-2.0
 * Copyright the Kamiframe contributors.
 *
 * One frame, and the accounting that goes with it.
 *
 * Note what is absent: there is no loop here. kf_app_frame() runs exactly one
 * frame and returns. Whichever backend is linked owns the loop. See kf/app.h.
 */

#include "kf/app.h"

#include "kf/arena.h"
#include "kf/blit.h"
#include "kf/budget.h"
#include "kf/font.h"
#include "kf/framebuffer.h"
#include "kf/hal/display.h"
#include "kf/hal/entropy.h"
#include "kf/hal/input.h"
#include "kf/hal/log.h"
#include "kf/hal/power.h"
#include "kf/hal/storage.h"
#include "kf/hal/time.h"
#include "kf/demo.h"

#include <cstdint>
#include <cstring>

#include "kf/poison.h"

namespace {

constexpr const char *TAG = "app";

/* Rolling window for the frame-time summary. 256 frames is a few seconds at
 * 30fps: long enough for p99 to mean something, short enough to react. */
constexpr int kWindow = 256;

struct AppState {
    bool initialised = false;
    bool running = false;

    uint64_t frame_index = 0;
    uint64_t frame_start_us = 0;

    kf_frame_stats last{};

    uint32_t window[kWindow] = {};
    int window_count = 0;
    int window_next = 0;

    uint64_t total_frames = 0;
    uint64_t over_budget_frames = 0;
    uint32_t worst_us = 0;

    uint64_t last_report_us = 0;

    /* Debounced button state, computed in core so the device and the
     * simulator feel the same. */
    uint32_t buttons_stable = 0;
    uint32_t buttons_candidate = 0;
    uint64_t candidate_since_us = 0;
    uint32_t buttons_pressed_edge = 0;

    /* The constraint HUD from ADR 0006's "Later" section. Off by default:
     * it is a development affordance, not something the device shows a
     * user, and keeping it off keeps the golden-frame and dirty-area tests
     * (which never press MENU) exercising the demo alone. Toggle with
     * KF_BTN_MENU. */
    bool hud_visible = false;
};

AppState g;

/* Physical switches bounce for a few milliseconds when pressed. 8ms is the
 * usual safe figure. Doing this in core rather than per-backend means the
 * simulator has the same input latency as the hardware, which matters because
 * input latency is something you tune by feel. */
constexpr uint64_t kDebounceUs = 8000;

void debounce(const kf_input_raw &raw) {
    if (raw.buttons != g.buttons_candidate) {
        g.buttons_candidate = raw.buttons;
        g.candidate_since_us = raw.sampled_at_us;
        return;
    }
    if (g.buttons_candidate != g.buttons_stable &&
        raw.sampled_at_us - g.candidate_since_us >= kDebounceUs) {
        const uint32_t previous = g.buttons_stable;
        g.buttons_stable = g.buttons_candidate;
        g.buttons_pressed_edge = g.buttons_stable & ~previous;
    } else {
        g.buttons_pressed_edge = 0;
    }
}

/* Device draw time from the pixel count, not from the host clock. See the
 * KF_DRAW_* rates in budget.h and the comment above them. */
uint32_t estimate_draw_us(const kf_draw_counters &c) {
    const uint32_t opaque = c.opaque_pixels / KF_DRAW_OPAQUE_PX_PER_US;
    const uint32_t keyed = c.keyed_pixels / KF_DRAW_KEYED_PX_PER_US;
    return opaque + keyed;
}

/* What the panel link would cost for `bytes`, in microseconds.
 *
 * This is the number your desktop reports as zero and the device cannot
 * escape. See KF_DISPLAY_SPI_HZ in budget.h for the arithmetic. */
uint32_t estimate_transfer_us(size_t bytes, uint32_t link_bytes_per_second) {
    if (link_bytes_per_second == 0u || bytes == 0u) {
        return 0u;
    }
    const uint64_t us =
        (static_cast<uint64_t>(bytes) * 1000000ull) / link_bytes_per_second;
    return static_cast<uint32_t>(us);
}

void record(uint32_t total_us) {
    g.window[g.window_next] = total_us;
    g.window_next = (g.window_next + 1) % kWindow;
    if (g.window_count < kWindow) {
        g.window_count++;
    }
    g.total_frames++;
    if (total_us > g.worst_us) {
        g.worst_us = total_us;
    }
}

/* Insertion sort over at most 256 entries, into the per-frame scratch arena.
 * Called once a second for the report, never in the hot path. */
uint32_t percentile(int pct) {
    if (g.window_count == 0) {
        return 0u;
    }
    const int n = g.window_count;
    uint32_t *sorted = static_cast<uint32_t *>(
        kf_arena_alloc(KF_ARENA_SCRATCH, sizeof(uint32_t) * static_cast<size_t>(n),
                       alignof(uint32_t)));
    memcpy(sorted, g.window, sizeof(uint32_t) * static_cast<size_t>(n));

    for (int i = 1; i < n; ++i) {
        const uint32_t key = sorted[i];
        int j = i - 1;
        while (j >= 0 && sorted[j] > key) {
            sorted[j + 1] = sorted[j];
            j--;
        }
        sorted[j + 1] = key;
    }

    int index = (n * pct) / 100;
    if (index >= n) {
        index = n - 1;
    }
    return sorted[index];
}

/* --------------------------------------------------------------------------
 * Constraint HUD -- ADR 0006's "Later" section, now.
 *
 * Hand-rolled string building rather than snprintf: core has no heap, this
 * is a handful of digits, and a target that is not glibc is not somewhere
 * to trust a general formatter blindly. kf/poison.h would not even let this
 * file pull in <cstdio> for it.
 * -------------------------------------------------------------------------- */

char *append_str(char *dst, const char *end, const char *s) {
    while (*s != '\0' && dst < end) {
        *dst++ = *s++;
    }
    return dst;
}

char *append_uint(char *dst, const char *end, uint32_t v) {
    char digits[10];
    int n = 0;
    if (v == 0u) {
        digits[n++] = '0';
    }
    while (v > 0u && n < static_cast<int>(sizeof(digits))) {
        digits[n++] = static_cast<char>('0' + (v % 10u));
        v /= 10u;
    }
    while (n > 0 && dst < end) {
        *dst++ = digits[--n];
    }
    return dst;
}

/* `tenths` is already scaled by 10, e.g. pass fps*10 to print one decimal. */
char *append_fixed1(char *dst, const char *end, uint32_t tenths) {
    dst = append_uint(dst, end, tenths / 10u);
    if (dst < end) {
        *dst++ = '.';
    }
    if (dst < end) {
        *dst++ = static_cast<char>('0' + (tenths % 10u));
    }
    return dst;
}

/* Every HUD field (fps, us, percent, rect count, arena bytes) varies in digit
 * width frame to frame. kf_text_draw only paints cells for the characters it
 * is given -- that IS the "clear whatever was there" step (see its comment in
 * kf/font.cpp) -- so a line that got shorter than last frame leaves the old
 * tail's glyphs sitting in the framebuffer forever, uncleared, because
 * nothing ever draws over those cells again. Padding every line out to a
 * fixed width with spaces means this frame's draw always covers last frame's
 * worst case, at the cost of a few extra cheap background-only cells. */
constexpr int kHudLineWidth = 40;

char *pad_to(char *dst, const char *end, const char *line_start, int width) {
    while ((dst - line_start) < width && dst < end) {
        *dst++ = ' ';
    }
    return dst;
}

/* Drawn between the demo's draw call and this frame's own accounting, using
 * LAST frame's stats -- this frame cannot know its own total cost until
 * after it finishes, the same way a runner cannot time their own race
 * before crossing the line. One frame of lag on a HUD redrawn 30 times a
 * second is not something a human notices. */
void draw_hud(void) {
    constexpr kf_color kHudFg = KF_RGB(230, 235, 245);
    constexpr kf_color kHudBg = KF_RGB(20, 22, 32);

    /* Zero-initialised, not just declared: an uninitialised char[48] is fine
     * in practice (only the bytes up to the final NUL are ever read), but
     * GCC's -Wmaybe-uninitialized cannot see that from the pointer
     * arithmetic alone and flags `end` as possibly-uninitialized without
     * this. Cheap, and it settles the analysis instead of arguing with it. */
    char line[48] = {};
    const char *end = line + sizeof(line) - 1;
    char *w;

    w = line;
    w = append_str(w, end, "F");
    w = append_fixed1(w, end,
                       g.last.total_us > 0u
                           ? static_cast<uint32_t>(10000000ull / g.last.total_us)
                           : 0u);
    w = append_str(w, end, "FPS ");
    w = append_uint(w, end, g.last.total_us);
    w = append_str(w, end, "US D");
    w = append_uint(w, end, g.last.dirty_percent);
    w = append_str(w, end, "% R");
    w = append_uint(w, end, g.last.dirty_rect_count);
    if (g.last.over_budget) {
        w = append_str(w, end, " OVER");
    }
    w = pad_to(w, end, line, kHudLineWidth);
    *w = '\0';
    kf_text_draw(0, 0, line, kHudFg, kHudBg);

    /* One line per arena. Names are lowercase in kf/arena.cpp; the font is
     * uppercase-only (see kf/font.h), so upper-case them here rather than
     * widen the font for one call site. */
    constexpr kf_arena_id kArenas[] = {KF_ARENA_FRAMEBUFFER, KF_ARENA_SCRATCH,
                                       KF_ARENA_LUA, KF_ARENA_ASSETS};
    for (size_t i = 0; i < sizeof(kArenas) / sizeof(kArenas[0]); ++i) {
        const kf_arena_stats *s = kf_arena_get_stats(kArenas[i]);
        w = line;
        for (const char *n = s->name; *n != '\0' && w < end; ++n) {
            *w++ = static_cast<char>((*n >= 'a' && *n <= 'z')
                                          ? (*n - 'a' + 'A')
                                          : *n);
        }
        w = append_str(w, end, " ");
        w = append_uint(w, end,
                        static_cast<uint32_t>(s->high_water_bytes / 1024u));
        w = append_str(w, end, "/");
        w = append_uint(w, end,
                        static_cast<uint32_t>(s->capacity_bytes / 1024u));
        w = append_str(w, end, "K");
        w = pad_to(w, end, line, kHudLineWidth);
        *w = '\0';
        kf_text_draw(0,
                     static_cast<int16_t>(KF_FONT_CELL_H *
                                           (1 + static_cast<int>(i))),
                     line, kHudFg, kHudBg);
    }
}

} // namespace

void kf_app_init(kf_demo_mode mode) {
    KF_ASSERT(!g.initialised, "kf_app_init called twice");

    KF_LOGI(TAG, "HakoniwaOS starting");

    /* Arenas first: everything else allocates from them. */
    kf_arena_init_all();

    KF_ASSERT(kf_time_init() == KF_OK, "time HAL failed to start");
    KF_ASSERT(kf_display_init() == KF_OK, "display HAL failed to start");
    KF_ASSERT(kf_input_init() == KF_OK, "input HAL failed to start");
    KF_ASSERT(kf_store_init() == KF_OK, "storage HAL failed to start");
    KF_ASSERT(kf_power_init() == KF_OK, "power HAL failed to start");

    const kf_display_caps *caps = kf_display_get_caps();
    KF_ASSERT(caps != nullptr, "display backend returned no capabilities");

    /* budget.h describes the panel core allocates for; caps describes the
     * panel that is actually attached. A future e-ink or mono variant makes
     * these diverge legitimately, and that is the day this check becomes a
     * real branch rather than an assert. */
    KF_ASSERT(caps->width == KF_DISPLAY_WIDTH &&
                  caps->height == KF_DISPLAY_HEIGHT,
              "Display backend reports %ux%u but kf/budget.h is built for "
              "%dx%d. A backend for a different panel needs core to handle "
              "capability-driven sizing, which it does not do yet.",
              caps->width, caps->height, KF_DISPLAY_WIDTH, KF_DISPLAY_HEIGHT);
    KF_ASSERT(caps->format == KF_PIXFMT_RGB565,
              "Display backend is not RGB565. Core only speaks RGB565 today.");

    kf_fb_init();

    uint32_t seed = 0;
    KF_ASSERT(kf_entropy(&seed, sizeof(seed)) == KF_OK,
              "entropy HAL failed to start");

    kf_demo_init(seed, mode);

    const kf_wall_time now = kf_time_wall();
    KF_LOGI(TAG, "wall clock %s (epoch %lld)",
            now.valid ? "valid" : "UNSET",
            static_cast<long long>(now.epoch_seconds));
    KF_LOGI(TAG, "budget: %d fps, %u us per frame, link %u bytes/s",
            KF_TARGET_FPS, static_cast<unsigned>(KF_FRAME_BUDGET_US),
            caps->link_bytes_per_second);
    KF_LOGI(TAG, "press MENU to toggle the on-screen constraint HUD");

    g.last_report_us = kf_time_mono_us();
    g.initialised = true;
    g.running = true;
}

bool kf_app_frame(void) {
    KF_ASSERT(g.initialised, "kf_app_frame before kf_app_init");

    g.frame_start_us = kf_time_mono_us();

    /* Everything allocated last frame is gone. Nothing may survive here. */
    kf_arena_reset(KF_ARENA_SCRATCH);
    kf_draw_counters_reset();

    kf_input_raw raw{};
    if (kf_input_poll(&raw) == KF_OK) {
        if (raw.quit_requested) {
            g.running = false;
        }
        debounce(raw);
    }

    if (g.buttons_pressed_edge & KF_BTN_MENU) {
        g.hud_visible = !g.hud_visible;
        /* Whichever way it just toggled, something on screen needs a
         * clean repaint: turning the HUD off leaves its last frame's
         * pixels sitting in the framebuffer with nothing left to redraw
         * them, and only the demo knows its own background colour. */
        kf_demo_request_full_repaint();
    }

    kf_demo_update(g.buttons_stable, g.buttons_pressed_edge);
    kf_demo_draw();

    if (g.hud_visible) {
        draw_hud();
    }

    const kf_dirty_rects dirty = kf_fb_dirty_rects();
    const size_t dirty_bytes = kf_fb_dirty_bytes();

    kf_display_present(kf_fb_pixels(), dirty.rects, dirty.count);
    kf_fb_clear_dirty();

    const uint64_t end_us = kf_time_mono_us();
    const uint32_t cpu_us = static_cast<uint32_t>(end_us - g.frame_start_us);

    const kf_display_caps *caps = kf_display_get_caps();
    /* Pixel bytes plus the per-rectangle addressing overhead each separate
     * rectangle costs on real hardware -- see KF_DISPLAY_RECT_OVERHEAD_BYTES
     * in kf/budget.h. Without this term, splitting one rectangle into many
     * would look free, which is exactly the kind of lie this estimate exists
     * to not tell. */
    const size_t overhead_bytes =
        static_cast<size_t>(dirty.count) * KF_DISPLAY_RECT_OVERHEAD_BYTES;
    const uint32_t transfer_us = estimate_transfer_us(
        dirty_bytes + overhead_bytes, caps->link_bytes_per_second);

    const kf_draw_counters counters = kf_draw_counters_get();
    const uint32_t draw_us = estimate_draw_us(counters);

    g.last.frame_index = g.frame_index;
    g.last.cpu_us = cpu_us;
    g.last.draw_us = draw_us;
    g.last.opaque_pixels = counters.opaque_pixels;
    g.last.keyed_pixels = counters.keyed_pixels;
    g.last.transfer_us = transfer_us;
    g.last.serial_us = draw_us + transfer_us;
    g.last.overlapped_us = draw_us > transfer_us ? draw_us : transfer_us;
    g.last.total_us =
        KF_DISPLAY_DOUBLE_BUFFERED ? g.last.overlapped_us : g.last.serial_us;
    g.last.over_budget = g.last.total_us > KF_FRAME_BUDGET_US;
    g.last.dirty_percent = static_cast<uint8_t>(
        (static_cast<uint64_t>(dirty_bytes / sizeof(kf_color)) * 100ull) /
        static_cast<uint64_t>(KF_FRAMEBUFFER_PIXELS));
    g.last.dirty_rect_count = static_cast<uint8_t>(dirty.count);

    record(g.last.total_us);
    if (g.last.over_budget) {
        g.over_budget_frames++;
    }
    g.frame_index++;

    /* Report roughly once a second. Cheap, and it means the numbers are in
     * front of you constantly rather than only when you go looking. */
    if (end_us - g.last_report_us >= 1000000ull) {
        kf_app_log_budget_report();
        g.last_report_us = end_us;
    }

    /* Pace the simulator against the HOST clock, using real elapsed time
     * rather than the modelled device time. Otherwise the window would run at
     * a speed unrelated to anything. The device will replace this with a
     * light sleep, which is where the battery life comes from. */
    if (cpu_us < KF_FRAME_BUDGET_US) {
        kf_time_delay_us(KF_FRAME_BUDGET_US - cpu_us);
    }

    return g.running;
}

void kf_app_shutdown(void) {
    if (!g.initialised) {
        return;
    }
    KF_LOGI(TAG, "shutting down after %llu frames",
            static_cast<unsigned long long>(g.total_frames));
    kf_app_log_budget_report();

    kf_demo_shutdown();
    kf_input_shutdown();
    kf_display_shutdown();
    kf_power_shutdown();
    kf_store_shutdown();
    g.initialised = false;
    g.running = false;
}

const kf_frame_stats *kf_app_last_frame(void) { return &g.last; }

kf_frame_summary kf_app_frame_summary(void) {
    kf_frame_summary s{};
    s.frames = g.total_frames;
    s.over_budget_frames = g.over_budget_frames;
    s.last_us = g.last.total_us;
    s.worst_us = g.worst_us;

    if (g.window_count > 0) {
        uint64_t sum = 0;
        for (int i = 0; i < g.window_count; ++i) {
            sum += g.window[i];
        }
        s.mean_us = static_cast<uint32_t>(sum / static_cast<uint64_t>(g.window_count));
        s.p99_us = percentile(99);
    }
    return s;
}

void kf_app_log_budget_report(void) {
    const kf_frame_summary s = kf_app_frame_summary();
    const kf_display_caps *caps = kf_display_get_caps();

    KF_LOGI(TAG, "---- frame budget (%d fps target, %u us) ----", KF_TARGET_FPS,
            static_cast<unsigned>(KF_FRAME_BUDGET_US));
    KF_LOGI(TAG, "  device estimate: draw %5u us + transfer %5u us",
            g.last.draw_us, g.last.transfer_us);
    KF_LOGI(TAG,
            "     serial (today)      %5u us  ->  %5.1f fps%s",
            g.last.serial_us,
            g.last.serial_us ? 1000000.0 / g.last.serial_us : 0.0,
            (!KF_DISPLAY_DOUBLE_BUFFERED && g.last.over_budget)
                ? "   OVER BUDGET"
                : "");
    KF_LOGI(TAG, "     overlapped (DMA+2buf) %5u us  ->  %5.1f fps",
            g.last.overlapped_us,
            g.last.overlapped_us ? 1000000.0 / g.last.overlapped_us : 0.0);
    KF_LOGI(TAG, "  pixels drawn: %6u opaque + %6u keyed   dirty %3u%%  (%u rect%s)",
            g.last.opaque_pixels, g.last.keyed_pixels, g.last.dirty_percent,
            g.last.dirty_rect_count, g.last.dirty_rect_count == 1 ? "" : "s");
    KF_LOGI(TAG, "  host cpu %5u us (your PC, not the device)", g.last.cpu_us);
    KF_LOGI(TAG, "  mean %5u us   p99 %5u us   worst %5u us", s.mean_us,
            s.p99_us, s.worst_us);
    KF_LOGI(TAG, "  frames %llu, over budget %llu (%llu%%)",
            static_cast<unsigned long long>(s.frames),
            static_cast<unsigned long long>(s.over_budget_frames),
            s.frames ? static_cast<unsigned long long>(
                           (s.over_budget_frames * 100ull) / s.frames)
                     : 0ull);

    /* The number that most often explains a bad p99: a full-screen redraw at
     * 40MHz costs about 30ms of wire time all by itself. */
    const uint32_t full_frame_us =
        estimate_transfer_us(KF_FRAMEBUFFER_BYTES, caps->link_bytes_per_second);
    KF_LOGI(TAG, "  a FULL frame would cost %u us of transfer alone",
            full_frame_us);

    KF_LOGI(TAG, "---- arenas ----");
    kf_arena_log_all();
}
